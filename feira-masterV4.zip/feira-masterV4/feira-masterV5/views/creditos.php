<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/style.css" />
    <title>Créditos</title>
    <style>
      .card-cred{
        height: 150px;
      }
      .voltar{
        width: 100px;
        position: fixed;
        z-index: 2;
      }
    </style>
  </head>
  <body
    style="
      background-image: url('/images/bg-preto.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
    "
  >
    <header>
      <img src="images/mcm-logo.png" alt="logo" />
      <h1>Créditos</h1>
      <img src="images/cps-logo.png" alt="logo" />
    </header>
    <a href="tela_home.php" class="voltar" >Voltar</a>
    <main style="padding: 0px">
      <div class="holder-cred-cat">
        <!--titulo-->
        <div class="sep-cat-cred"><p class="title-cred-cat">Back-end</p></div>
        <!--fim do titulo-->
        <div class="holder-cred-card">
          <!-- Cartões gerados dinamicamente a partir do banco de dados -->
          <?php
            $dados = [
              ["Ângelo Gabriel", "/imagens", "Team leader - Back", null, "https://github.com/projAngeloAraujo"],
              ["Enzo Móbile", "/imagens", "Programador - Back", null, "https://github.com/enzomobile"],
              ["Guilherme Solon", "/imagens", "Programador - Back", "https://www.linkedin.com/in/guilherme-solon-6b4a142a9/", "https://github.com/Solonguitec"],
              ["Gustavo da Rocha", "/imagens", "Programador - Back", null, "https://github.com/gustapinheiro"],
              ["Gustavo Rangel", "/imagens", "Programador - Back", null, "https://github.com/DEVRangelll"],
              ["Iuri Carati", "/imagens", "Programador - Back", null, "https://github.com/ToxicDumpster"],
              ["Jean Marcos", "/imagens", "Programador - Back", null, "https://github.com/jean666"],
              ["Júlia Medeiros", "/imagens", "Programadora - Back", null, "https://github.com/jumedeirost"],
              ["Matheus Pereira", "/imagens", "Programador - Back", null, "https://github.com/MatheusSontos"],
              ["Miguel Sommerfeld", "/imagens", "Team leader - Back", "https://www.linkedin.com/in/miguel-sommerfeld-06491b340/", "https://github.com/MiguelSommerf"],
              ["Miguel Teodoro", "/imagens", "Programador - Back", null, "https://github.com/Miguelteodorodesouza"],
              ["Sabrina Bela", "/imagens", "Programadora - Back", null, "https://github.com/sabrinabela1"],
              ["Stephany dos Santos", "/imagens", "Programadora - Back", null, "https://github.com/stephanydossantos16"],
              ["Thomas Coradi", "/imagens", "Programador - Back", null, "https://github.com/thomcoradi"]
            ];

            foreach ($dados as $pessoa) {
              echo "<div class='card-cred'>";
              echo "<img class='foto-perfil-cred' src='{$pessoa[1]}' alt='{$pessoa[0]}' />";
              echo "<div class='inf-holder-cred'>";
              echo "<div><h2>{$pessoa[0]}</h2><h3>{$pessoa[2]}</h3></div>";
              echo "<div><p>me encontre:</p><div class='div-btn-cred'>";
              if ($pessoa[4]) echo "<a class='btn-cred-git' href='{$pessoa[4]}'>Git</a>";
              if ($pessoa[3]) echo "<a class='btn-cred-lin' href='{$pessoa[3]}'>LinkedIn</a>";
              echo "</div></div></div></div>";
            }
          ?>
        </div>
        <div class="sep-cat-cred"><p class="title-cred-cat">Banco de Dados</p></div>
        <div class="holder-cred-card">
          <?php
            $dadosBanco = [
              ["Amanda Rodriguez", "/imagens", "Administradora - Banco de Dados", "", "https://github.com/amandszr"],
              ["Bryan de Oliveira", "/imagens", "Administrador - Banco de Dados", "", "https://github.com/BryanOli17"],
              ["Denner Pereira", "/imagens", "Administrador - Banco de Dados", "", "https://github.com/Denner106"],
              ["Guilherme Benatte", "/imagens", "Team leader - Banco de Dados", "", "https://github.com/guibenatte"],
              ["Katharina Iaussoghi", "/imagens", "Administradora - Banco de Dados", "", "https://github.com/Katharinasilveira"],
              ["Mariana Campello", "/imagens", "Administradora - Banco de Dados", "https://www.linkedin.com/in/mariana-cunha-campello-b865b5363/", "https://github.com/marianacampelo"],
              ["Nicole Pereira", "/imagens", "Administradora - Banco de Dados", "", "https://github.com/Nicolepereiragregorutti"],
              ["Rafaela Mayumi", "/imagens", "Team leader - Banco de Dados", "", "https://github.com/RafaelaMayumiFukuda"]
            ];

            foreach ($dadosBanco as $pessoa) {
              echo "<div class='card-cred'>";
              echo "<img class='foto-perfil-cred' src='{$pessoa[1]}' alt='{$pessoa[0]}' />";
              echo "<div class='inf-holder-cred'>";
              echo "<div><h2>{$pessoa[0]}</h2><h3>{$pessoa[2]}</h3></div>";
              echo "<div><p>me encontre:</p><div class='div-btn-cred'>";
              if ($pessoa[4]) echo "<a class='btn-cred-git' href='{$pessoa[4]}'>Git</a>";
              if ($pessoa[3]) echo "<a class='btn-cred-lin' href='{$pessoa[3]}'>LinkedIn</a>";
              echo "</div></div></div></div>";
            }
          ?>
        </div>

        <div class="sep-cat-cred"><p class="title-cred-cat">Front-end</p></div>
        <div class="holder-cred-card">
          <?php
            $dadosFront = [
              ["Amanda Kaori", "/imagens", "Programadora - Front", null, "https://github.com/projamandakaori"],
              ["Camila Vitoria", "/imagens", "Programadora - Front", null, "https://github.com/ProjCamilaVitoria"],
              ["Cauã Arthur", "/imagens", "Programador - Front", null, "https://github.com/Projcauaramos"],
              ["Cecília Santiago", "/imagens", "Programadora - Front", null, "https://github.com/ceciliasf"],
              ["Eduardo de Ataíde", "/imagens", "Programador - Front", null, "https://github.com/duduusxz"],
              ["Giulia Benedetti", "/imagens", "Team leader - Front", null, "https://github.com/projgioliveira"],
              ["João Xavier", "/imagens", "Programador - Front", "https://www.linkedin.com/in/jo%C3%A3o-vitor-xavier-de-carvalho-469147183/?trk=opento_nprofile_details", "https://github.com/joaovitorxc"],
              ["Kevin Rafael", "/imagens", "Programador - Front", null, "https://github.com/Kevin2007x"],
              ["Lívia Amaral", "/imagens", "Team leader - Front", "https://www.linkedin.com/in/l%C3%ADvia-amaral-sales-antonio-675219326/", "https://github.com/Liviaamaralsales"],
              ["Olavo Alves", "/imagens", "Programador - Front", null, "https://github.com/Olavoschiavi"],
              ["Sabrina Vitória", "/imagens", "Programadora - Front", null, "https://github.com/Sabrinavmoura"],
              ["Stefanny Sayuri", "/imagens", "Programadora - Front", null, "https://github.com/StefannySayuri"],
              ["Welington Fernando", "/imagens", "Programador - Front", null, "https://github.com/Welingtonf"]
            ];

            foreach ($dadosFront as $pessoa) {
              echo "<div class='card-cred'>";
              echo "<img class='foto-perfil-cred' src='{$pessoa[1]}' alt='{$pessoa[0]}' />";
              echo "<div class='inf-holder-cred'>";
              echo "<div><h2>{$pessoa[0]}</h2><h3>{$pessoa[2]}</h3></div>";
              echo "<div><p>me encontre:</p><div class='div-btn-cred'>";
              if ($pessoa[4]) echo "<a class='btn-cred-git' href='{$pessoa[4]}'>Git</a>";
              if ($pessoa[3]) echo "<a class='btn-cred-lin' href='{$pessoa[3]}'>LinkedIn</a>";
              echo "</div></div></div></div>";
            }
          ?>
        </div>
        <div class="sep-cat-cred"><p class="title-cred-cat">Gestão</p></div>
        <div class="holder-cred-card">
          <?php
            $dadosGestao = [
              ["Giovana Pracanico", "/imagem", "Gestão", null, "https://github.com/projgipracanico"],
              ["Heitor Albuquerque", "/imagens", "gestor", null, "https://github.com/projheitorfreitas"],
              ["Joshua Rodrigues", "/imagens", "gestor", null, "https://github.com/JoshRodriguescae"],
              ["Luara Gouveia", "/imagens", "gestora", null, "https://github.com/luarag45"]
            ];

            foreach ($dadosGestao as $pessoa) {
              echo "<div class='card-cred'>";
              echo "<img class='foto-perfil-cred' src='{$pessoa[1]}' alt='{$pessoa[0]}' />";
              echo "<div class='inf-holder-cred'>";
              echo "<div><h2>{$pessoa[0]}</h2><h3>{$pessoa[2]}</h3></div>";
              echo "<div><p>me encontre:</p><div class='div-btn-cred'>";
              if ($pessoa[4]) echo "<a class='btn-cred-git' href='{$pessoa[4]}'>Git</a>";
              if ($pessoa[3]) echo "<a class='btn-cred-lin' href='{$pessoa[3]}'>LinkedIn</a>";
              echo "</div></div></div></div>";
            }
          ?>
        </div>

        <div class="sep-cat-cred"><p class="title-cred-cat">Orientadores</p></div>
        <div class="holder-cred-card">
          <?php
            $dadosOrientadores = [
              ["Ricardo Moreira", "/imagens", "Orientador do projeto", null, "https://github.com/prof-ricardo"],
              ["Edilma Bindá", "/imagens", "Orientadora do projeto", null, "https://github.com/edilmabinda"]
            ];

            foreach ($dadosOrientadores as $pessoa) {
              echo "<div class='card-cred'>";
              echo "<img class='foto-perfil-cred' src='{$pessoa[1]}' alt='{$pessoa[0]}' />";
              echo "<div class='inf-holder-cred'>";
              echo "<div><h2>{$pessoa[0]}</h2><h3>{$pessoa[2]}</h3></div>";
              echo "<div><p>me encontre:</p><div class='div-btn-cred'>";
              if ($pessoa[4]) echo "<a class='btn-cred-git' href='{$pessoa[4]}'>Git</a>";
              if ($pessoa[3]) echo "<a class='btn-cred-lin' href='{$pessoa[3]}'>LinkedIn</a>";
              echo "</div></div></div></div>";
            }
          ?>
        </div>
      </div>
    </main>
  </body>
</html>
