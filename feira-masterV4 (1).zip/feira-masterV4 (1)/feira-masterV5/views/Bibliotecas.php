<!DOCTYPE html>
<html lang="pt-br">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="../css/style.css"> <!-- Caminho CSS -->
 <title>Biblioteca</title> <!-- Nome da Tela -->
</head>
<body>
<header>
<img src="images/mcm-logo.png" alt="logo-etec">
<h1>Cadastro</h1> <!-- Nome da Tela -->
<img src="images/cps-logo.png" alt="logo-cps">
 </header>
 <a href="Locais.php" class="voltar">voltar</a>
 <div class="titulo"><p class="titulo-e">Biblioteca</p></div>
 <main>
  <div class="home-holder">
    <div class="home-conteiner-quadra">
      <div class="corpo"></div>
      <div class="stands">
        <div class="stand">Stand 16<br>Nome projeto</div>
        <div class="stand">Stand 15<br>Nome projeto</div>
        <div class="stand">Stand 14<br>Nome projeto</div>
        <div class="stand">Stand 13<br>Nome projeto</div>
        <div class="stand">Stand 12<br>Nome projeto</div>
        <div class="stand">Stand 11<br>Nome projeto</div>
        <div class="stand">Stand 10<br>Nome projeto</div>
        <div class="stand">Stand 9<br>Nome projeto</div>
        <div class="stand">Stand 8<br>Nome projeto</div>
        <div class="stand">Stand 7<br>Nome projeto</div>
        <div class="stand">Stand 6<br>Nome projeto</div>
        <div class="stand">Stand 5<br>Nome projeto</div>
        <div class="stand">Stand 4<br>Nome projeto</div>
        <div class="stand">Stand 3<br>Nome projeto</div>
        <div class="stand">Stand 2<br>Nome projeto</div>
        <div class="stand">Stand 1<br>Nome projeto</div>
        <!-- outros stands -->
      </div>
    </div>
  </div>
  </div>  
 </main>
</body>
</html>
